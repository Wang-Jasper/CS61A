Homework 11 | CS 61A Spring 2024
================================

Homework 11: Finale[​](https://www.learncs.site/docs/curriculum-resource/cs61a/homework/hw11#homework-11-finale "Direct link to Homework 11: Finale")
-----------------------------------------------------------------------------------------------------------------------------------------------------

_Due by 11:59pm on Sunday, May 5_

This homework has nothing you need to submit to Gradescope. Rather, there are 3 surveys you need to fill out.

*   Complete the [61A end-of-semester survey](https://forms.gle/vY3xWvk71tpF8x8K9),
*   Fill out the [UC Berkeley course evaluations](https://course-evaluations.berkeley.edu/), and
*   [Vote](https://forms.gle/dTzYHR23ZMDQ8URp6) on your favorite [Scheme art](https://cs61a.org/proj/scheme_gallery).

If 80% or more students (computed as the fraction of the number of students who took Midterm 2) complete all three, then all students who complete this homework get an extra credit point!