/* Start/end date of semester. Make sure to change utils.py as well */
var startDate = '2020-08-26', endDate = '2020-12-04';

/* Calendar Specification */
var officeHoursCalendarId = 'c_qbhh4qrvvd5lhgnrikeh8tqhos@group.calendar.google.com';
var instructorOfficeHoursCalendarId = '';
var lecturesCalendarId = 'c_49p44snsa9d2roc3fv0j0h31no@group.calendar.google.com';
var sectionsCalendarId = 'c_e61er5dri18gquei9i7uq9okbs@group.calendar.google.com';
