# CS61A 2020 Fall Mirror

UCB have closed the public 61A site for unknown reason,  
this is the mirror of all resources on the website,  
downloaded from the Wayback Machine.   
